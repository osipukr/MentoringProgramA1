﻿CREATE SCHEMA [Northwind]
