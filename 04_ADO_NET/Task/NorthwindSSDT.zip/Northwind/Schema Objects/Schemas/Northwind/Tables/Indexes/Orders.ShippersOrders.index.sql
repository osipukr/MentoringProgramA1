﻿CREATE NONCLUSTERED INDEX [ShippersOrders] ON [Northwind].[Orders] 
(
	[ShipVia] ASC
)