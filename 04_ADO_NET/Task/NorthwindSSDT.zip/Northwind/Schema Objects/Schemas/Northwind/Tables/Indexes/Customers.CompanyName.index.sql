﻿CREATE NONCLUSTERED INDEX [CompanyName] ON [Northwind].[Customers] 
(
	[CompanyName] ASC
)