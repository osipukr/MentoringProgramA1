﻿CREATE NONCLUSTERED INDEX [PostalCode] ON [Northwind].[Suppliers] 
(
	[PostalCode] ASC
)