﻿CREATE NONCLUSTERED INDEX [PostalCode] ON [Northwind].[Customers] 
(
	[PostalCode] ASC
)