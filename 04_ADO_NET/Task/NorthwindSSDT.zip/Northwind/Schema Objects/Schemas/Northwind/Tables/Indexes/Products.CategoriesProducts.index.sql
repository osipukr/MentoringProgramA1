﻿CREATE NONCLUSTERED INDEX [CategoriesProducts] ON [Northwind].[Products] 
(
	[CategoryID] ASC
)