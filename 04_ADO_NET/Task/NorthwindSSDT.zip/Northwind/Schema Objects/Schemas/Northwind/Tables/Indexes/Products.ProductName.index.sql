﻿CREATE NONCLUSTERED INDEX [ProductName] ON [Northwind].[Products] 
(
	[ProductName] ASC
)