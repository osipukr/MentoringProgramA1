﻿CREATE NONCLUSTERED INDEX [CustomerID] ON [Northwind].[Orders] 
(
	[CustomerID] ASC
)