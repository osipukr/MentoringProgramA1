﻿CREATE NONCLUSTERED INDEX [CompanyName] ON [Northwind].[Suppliers] 
(
	[CompanyName] ASC
)