﻿CREATE NONCLUSTERED INDEX [ProductID] ON [Northwind].[Order Details] 
(
	[ProductID] ASC
)