﻿CREATE NONCLUSTERED INDEX [LastName] ON [Northwind].[Employees] 
(
	[LastName] ASC
)