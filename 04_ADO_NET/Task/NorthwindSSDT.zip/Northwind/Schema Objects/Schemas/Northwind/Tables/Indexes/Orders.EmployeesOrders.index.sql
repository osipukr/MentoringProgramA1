﻿CREATE NONCLUSTERED INDEX [EmployeesOrders] ON [Northwind].[Orders] 
(
	[EmployeeID] ASC
)